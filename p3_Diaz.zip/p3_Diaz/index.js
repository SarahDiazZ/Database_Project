"use strict";
const { strict } = require('assert');
const { table } = require('console');
const express = require('express');
const mysql = require('mysql');
const app = express();
const port = 3001;

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "ChickenNuggets3233",
    database: "Hospital_Data"
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to SQL Database', err);
        return;
    }
    console.log("Database Connected!");
});

app.set("view engine", "ejs");
app.use(express.urlencoded());
app.use(express.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.get('/query', (req, res) => {
    const tableName = req.query.tableName;
    const sql = `SELECT * FROM ${tableName}`;
    connection.query(sql, (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.render('table', { tableName: tableName, results: results });
    });
});

app.get('/average', (req, res) => {
    const { tableName, columnName } = req.query;
    const sql = `SELECT AVG(${columnName}) AS average FROM ${tableName}`;
    connection.query(sql, (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.render('average', { tableName: tableName, columnName: columnName, average: results[0].average });
    });
});

app.get('/insert', (req, res) => {
    const tableName = req.query.tableName;
    const sql = `SHOW COLUMNS FROM ${tableName}`;
    connection.query(sql, (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        const columnNames = results.map(result => result.Field);
        res.render('insert', { tableName: tableName, columnNames: columnNames });
    });
});

app.post('/insert', (req, res) => {
    const tableName = req.query.tableName;
    const columns = Object.keys(req.body);
    const values = Object.values(req.body).map(value => `'${value}'`).join(', ');
    const sql = `INSERT INTO ${tableName} (${columns.join(', ')}) VALUES (${values})`;
    connection.query(sql, (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).send(`MySQL Error: ${err.message}`);
            return;
        }
        res.send('Record inserted successfully!');
    });
});

app.get('/delete', (req, res) => {
    const tableName = req.query.tableName;
    const sql = `SELECT * FROM ${tableName}`;
    connection.query(sql, (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        const columnNames = Object.keys(results[0]);
        res.render('delete', { 
            tableName: tableName, 
            columnNames: columnNames, 
            results: results 
        });
    });
});

//User has to input one record at a time
app.post('/delete', (req, res) => {
    const tableName = req.query.tableName;
    const sql = `SELECT * FROM ${tableName}`;
    const conditions = Object.entries(req.body).map(([column, value]) => `${column} = '${value}'`).join(' AND ');

    // Check if any of the input fields are empty
    if (Object.values(req.body).some(value => value === '')) {
        return res.status(400).send('All input fields are required');
    }

        const sqlDelete = `DELETE FROM ${tableName} WHERE ${conditions}`;
        connection.query(sqlDelete, (err, deleteResults) => {
            if (err) {
                console.error('Error executing delete query:', err);
                res.status(500).send(`MySQL Error: ${err.message}`);
                return;
            }
            if (deleteResults.affectedRows === 0) {
                return res.status(404).send('No record found matching the input');
            }
                connection.query(sql, (err, results) => {
                    if (err) {
                        console.error('Error executing query:', err);
                        res.status(500).send('Internal Server Error');
                        return;
                    }
                    res.render('table', { tableName: tableName, results: results });
                });

        });
});



connection.end
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
